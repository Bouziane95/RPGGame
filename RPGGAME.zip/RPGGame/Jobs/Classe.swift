//
//  Classe.swift
//  RPGGame
//
//  Created by admin on 04/12/2018.
//  Copyright © 2018 Bouziane. All rights reserved.
//

import Foundation
enum Classe{
    case Fighter, Colossus, Wizard, Dwarf
}
