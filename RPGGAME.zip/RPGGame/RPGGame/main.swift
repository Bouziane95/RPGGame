//
//  main.swift
//  RPGGame
//
//  Created by admin on 04/12/2018.
//  Copyright © 2018 Bouziane. All rights reserved.
//

import Foundation

let player1 = Player(id:1)
let player2 = Player(id:2)
var game = Game(player1:player1, player2:player2)
game.newGame()

