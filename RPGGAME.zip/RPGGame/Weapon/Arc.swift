//
//  Arc.swift
//  RPGGame
//
//  Created by admin on 04/12/2018.
//  Copyright © 2018 Bouziane. All rights reserved.
//

import Foundation
class Arc: Weapon{
    init(){
        super.init(damages: 40, name: "Arc", defaultDamageValue: 40)
    }
}
