//
//  Axe.swift
//  RPGGame
//
//  Created by admin on 04/12/2018.
//  Copyright © 2018 Bouziane. All rights reserved.
//

import Foundation
class Axe: Weapon{
    init(){
        super.init(damages: 30, name: "Hache", defaultDamageValue: 30)
    }
}
