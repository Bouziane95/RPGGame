//
//  ElderWand.swift
//  RPGGame
//
//  Created by admin on 04/12/2018.
//  Copyright © 2018 Bouziane. All rights reserved.
//

import Foundation
class ElderWand: Weapon{
    init(){
        super.init(damages: 50, name: "Baguette de sureau", defaultDamageValue: 50)
    }
}
