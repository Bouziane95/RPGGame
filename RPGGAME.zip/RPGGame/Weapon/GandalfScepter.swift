//
//  GandalfScepter.swift
//  RPGGame
//
//  Created by admin on 04/12/2018.
//  Copyright © 2018 Bouziane. All rights reserved.
//

import Foundation
class GandalfScepter: Weapon{
    init(){
        super.init(damages: 50, name: "Sceptre de Gandalf", defaultDamageValue: 50)
    }
}
