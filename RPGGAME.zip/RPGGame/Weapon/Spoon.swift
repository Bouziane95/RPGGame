//
//  Spoon.swift
//  RPGGame
//
//  Created by admin on 04/12/2018.
//  Copyright © 2018 Bouziane. All rights reserved.
//

import Foundation
class Spoon: Weapon{
    init(){
        super.init(damages: 1, name: "une cuillère", defaultDamageValue: 1)
    }
}
