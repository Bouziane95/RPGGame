//
//  WoodenStaff.swift
//  RPGGame
//
//  Created by admin on 04/12/2018.
//  Copyright © 2018 Bouziane. All rights reserved.
//

import Foundation
class WoodenStaff: Weapon{
    init(){
        super.init(damages: 2, name: "Sceptre en bois", defaultDamageValue: 2)
    }
}
