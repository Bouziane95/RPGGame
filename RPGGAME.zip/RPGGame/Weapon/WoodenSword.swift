//
//  WoodenSword.swift
//  RPGGame
//
//  Created by admin on 04/12/2018.
//  Copyright © 2018 Bouziane. All rights reserved.
//

import Foundation
class WoodenSword: Weapon{
    init(){
        super.init(damages: 2, name: "Epée en bois", defaultDamageValue: 2)
    }
}
